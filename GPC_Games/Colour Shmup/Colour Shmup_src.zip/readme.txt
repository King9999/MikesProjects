February 11, 2013
COLOUR SHMUP by Mike Murray
Twitter: @MikeADMurray
Site: http://mmking9999.com
Email: mmking9999@gmail.com
-----------------------------
Colour Shmup is a game for Game Prototype Challenge v16.  It's a shmup ("shoot 'em up") where the objective is to survive for as long as possible.

CONTROLS
---------
WASD - move cursor up/down on title screen.
	 - move player ship on game screen.
SPACE - confirm on title screen and about screen
	  - shoot bullets on game screen
DIRECTIONAL KEYS - change ship colour.

RAINBOW GAUGE
--------------
The rainbow gauge is your lifelife.  Keep it filled and you can survive longer.  If you manage to max it out, you will be invincible for a short duration,
and your bullets are powered up!  However, your gauge will be empty once the super state is over, and you'll be in danger of dying.

COLOURS
---------
The enemy will come in one of four colours.  White, Red, Black, and Blue.  If you touch an enemy who is your colour, you will absorb it and
receive energy for your gauge.  Otherwise, you will take damage.  If the gauge is empty after touching an enemy not of your colour, you die.

*Note that certain colours oppose each other.  White opposes Black, and Red opposes Blue.  If you touch an opposing colour, you will take more damage!  However, if you
destroy an enemy of an opposing colour, it will drop one of two power ups!

CREDITS
--------
Game Design & Programming by Mike Murray
Music is from Space Megaforce (aka Super Aleste in other countries)
Jason Kaplan for GPC
You for playing my game!