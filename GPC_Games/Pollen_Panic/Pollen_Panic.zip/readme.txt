Pollen Panic prototype by Mike Murray
----------------------------------------

You are an exterminator, and deadly flowers have infested your customers' lawn!  Your objective is to eliminate the red flowers (the red cylinders) and avoid their pollen.  The health represents your anti-plant armor's resistance to the deadly pollen.  If that reaches 0, you die.

CONTROLS:
Use the WASD keys to move, and the left mouse button to shoot.

GAMEPLAY:
Reload your weapon by moving your player to the truck (blue box) and remain there until the reload time counts down to 0.
Some of your health will be restored.  The less ammo you have, the longer it will take to reload, and the harder it will become to eliminate all of the flowers.

If you die, you will respawn immediately with full health and ammo. The game is over when all 30 flowers are killed.