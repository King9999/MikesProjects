﻿Trapper!  A game for Game Prototype Challenge v17 by Mike Murray
Contact: @MikeADMurray • mmking9999@gmail.com
Website: http://mmking9999.com
=====================================
The theme for GPCv17 is "island" and "entanglement."  Trapper! is a game where you must travel to
different islands and capture exotic creatures for research.  Trapper! is a puzzle game where the player lures
creatures into traps; when you move, all creatures move at the same time, but in opposite directions.

There are 10 stages to complete. Since this is a prototype, there's no ending, and the game simply resets back to
level 1.  Enjoy!

CREDITS
========
Jason P. Kaplan for GPC
StarTropics music by Nintendo
Player sprite by Nintendo
Creature Sprite by Nintendo