namespace TileCrusher.Scoring
{
    public class Score
    {
        public string Name;
        public int Value;

        public Score()
        {
        }

        public Score(string name, int value)
        {
            Name = name;
            Value = value;
        }
    }
}
