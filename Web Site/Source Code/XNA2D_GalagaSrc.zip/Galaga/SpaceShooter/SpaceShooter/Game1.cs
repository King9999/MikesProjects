using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SpaceShooter.Screen;

namespace SpaceShooter
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;

        // Audio
//        AudioEngine audioEngine;
//        WaveBank waveBank;
//        SoundBank soundBank;

        public enum GameState
        {
            StartScreen = 1,
            Running = 2,
            EndScreen = 3
        }

        //define the GameState enumeration
        GameState gameState = GameState.StartScreen;
        ScreenBase currentScreen = null;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            setWindowSize(800, 600);

            // too early to change state
        }

        public void setWindowSize(int x, int y)
        {
            graphics.PreferredBackBufferWidth = x;
            graphics.PreferredBackBufferHeight = y;
            graphics.ApplyChanges();
        }

        public void changeState(GameState gs)
        {
            if (currentScreen != null)
                currentScreen.Destroy();

            switch (gs)
            {
                case GameState.StartScreen:
                    currentScreen = new StartScreen(this);
                    break;

                case GameState.EndScreen:
                    currentScreen = new EndScreen(this);
                    break;

                case GameState.Running:
                    currentScreen = new GameScreen(this, graphics);
                    break;
            }

            // initialize this screen for usage
            currentScreen.Init();

            // keep the game state
            gameState = gs;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            changeState(GameState.StartScreen);

            // TODO: Add your initialization logic here
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            return;
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /*
         *  GameScreen & XNA Connector Code (Update & Draw)
         * 
         */

        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            if (!currentScreen.isActive())
            {
                switch (gameState)
                {
                    case GameState.StartScreen:
                        changeState(GameState.Running);
                        break;

                    case GameState.EndScreen:
                        changeState(GameState.StartScreen);
                        break;

                    case GameState.Running:
                        changeState(GameState.EndScreen);
                        break;
                }
            }
            else
                currentScreen.Update(gameTime);

            base.Update(gameTime);
        }


        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            currentScreen.Draw(gameTime);

            base.Draw(gameTime);
        }
    }
}
