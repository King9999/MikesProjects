﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using SpaceShooter.Screen;

namespace SpaceShooter
{
    class Enemy
    {
        private Vector2 position;
        private Vector2 originalPosition;
        
        Queue<Vector2> wayPoint = new Queue<Vector2>();        //used to set points for the enemy to follow.
        private Texture2D picture;
        private bool isPositioned = false;      //checks if enemy is positioned on screen after pathfinding
        

        private float speed = 150.0f;
        private float deltaX = 0.0f;
        private float deltaY = 0.0f;
        private float xLength = 0.0f;
        private float xStart = 0.0f;

        private bool firing = false;

        // period on which the enemy fires
        private float fireSpeed = 1.6f;

        //timer for when it's time to dive
        private float diveTimer = 0.0f;

        //timer for capturing
        private float captureTimer = 0.0f;

        private float totalTime = 0.0f;
        private float radius = 20.0f;

        public Vector2  Position        { get { return position; } }
        public float    Radius          { get { return radius; } }

        public bool     Firing          { set { firing = value; } get { return firing; } }

        public bool blnRight = true;

        private bool originalPositionMarked = false;    //used to mark an enemy's position and not change it
        private bool playerPositionMarked = false;      //marks a player's current position and not change it
        private bool diveFinished = false;
        private bool captureFinished = false;

              

        public Enemy(Texture2D picture, Vector2 startPosition, float stepSpeed, float fireDelay, int waypointType)
        {
            this.picture = picture;


            this.position = startPosition;
            this.speed = stepSpeed;

            // makes enemies fire at random delays
            this.fireSpeed += fireDelay;

            diveTimer = 300.0f;
            captureTimer = 300.0f;

            //enemy follows its chosen path once instantiated
            switch (waypointType)
            {
                case 1:
                    WayPoints();
                    break;
                case 2:
                    WayPoints2();
                    break;
                case 3:
                    WayPoints3();
                    break;
                case 4:
                    WayPoints4();
                    break;
                case 5:
                    WayPoints5();
                    break;
                case 6:
                    WayPoints6();
                    break;
            }
        }

        /*
         *  Action Members for crafting scene motion
         * 
         */

        public void SetAcrossMovement(float deltaX, float xLength)
        {
            this.deltaX = deltaX;
            this.xLength = xLength;
            xStart = position.X;
        }

        private void WayPoints()
        {
            //this is the path that each enemy takes before lining up in a row. What should happen is the enemy enters
            //the screen from the side, performs a loop, and then lines up on a row.

            wayPoint.Enqueue(new Vector2(-40, 400));    //the first waypoint should always start offscreen somewhere.
            wayPoint.Enqueue(new Vector2(100, 400));    //it also coincides with the starting positions in the enemyGenerator class
            wayPoint.Enqueue(new Vector2(200, 200));
            wayPoint.Enqueue(new Vector2(70, 250));
            wayPoint.Enqueue(new Vector2(100, 400));
            wayPoint.Enqueue(new Vector2(200, 300));
            wayPoint.Enqueue(new Vector2(250, 100));

            //this waypoint lines up the enemies using their starting position + a large enough number
            //so that they aren't off screen
            wayPoint.Enqueue(new Vector2(position.X + 390, 100));   
        }

        private void WayPoints2()
        {
            //enemies appear from top of the screen
            wayPoint.Enqueue(new Vector2(100, -40));
            wayPoint.Enqueue(new Vector2(100, 400));  
            wayPoint.Enqueue(new Vector2(600, 500));
            wayPoint.Enqueue(new Vector2(700, 500));
            wayPoint.Enqueue(new Vector2(730, 400));
            wayPoint.Enqueue(new Vector2(630, 270));
            wayPoint.Enqueue(new Vector2(700, 400));
            wayPoint.Enqueue(new Vector2(730, 300));
            wayPoint.Enqueue(new Vector2(630, 270));
            wayPoint.Enqueue(new Vector2(300, 250));
            wayPoint.Enqueue(new Vector2(250, 200));
            wayPoint.Enqueue(new Vector2(400, position.Y + 300));
        }

        private void WayPoints3()
        {
            //enemies come from right side of screen.
            wayPoint.Enqueue(new Vector2(900, 500));
            wayPoint.Enqueue(new Vector2(90, 400));
            wayPoint.Enqueue(new Vector2(90, 50));
            wayPoint.Enqueue(new Vector2(700, 50));
            wayPoint.Enqueue(new Vector2(700, 300));
            wayPoint.Enqueue(new Vector2(200, 300));
            wayPoint.Enqueue(new Vector2(250, 250));
            wayPoint.Enqueue(new Vector2(350, 160));
            wayPoint.Enqueue(new Vector2(position.X - 600, 160));
        }

        private void WayPoints4()
        {
            wayPoint.Enqueue(new Vector2(700, -40));
            wayPoint.Enqueue(new Vector2(700, 250));
            wayPoint.Enqueue(new Vector2(450, 300));
            wayPoint.Enqueue(new Vector2(400, 300));
            wayPoint.Enqueue(new Vector2(350, 230));
            wayPoint.Enqueue(new Vector2(500, 200));
            wayPoint.Enqueue(new Vector2(500, 150));
            wayPoint.Enqueue(new Vector2(400, 150));
            wayPoint.Enqueue(new Vector2(200, 180));
            wayPoint.Enqueue(new Vector2(230, 300));
            wayPoint.Enqueue(new Vector2(400, 380));
            wayPoint.Enqueue(new Vector2(450, 320));
            wayPoint.Enqueue(new Vector2(400, 280));
            wayPoint.Enqueue(new Vector2(400, position.Y + 320));
        }

        private void WayPoints5()
        {
            wayPoint.Enqueue(new Vector2(-40, 100));
            wayPoint.Enqueue(new Vector2(500, 450));
            wayPoint.Enqueue(new Vector2(700, 250));
            wayPoint.Enqueue(new Vector2(650, 150));
            wayPoint.Enqueue(new Vector2(150, 450));
            wayPoint.Enqueue(new Vector2(100, 400));
            wayPoint.Enqueue(new Vector2(150, 350));
            wayPoint.Enqueue(new Vector2(200, 300));
            wayPoint.Enqueue(new Vector2(250, 350));
            wayPoint.Enqueue(new Vector2(450, 400));
            wayPoint.Enqueue(new Vector2(500, 350));
            wayPoint.Enqueue(new Vector2(400, 250));
            wayPoint.Enqueue(new Vector2(position.X + 450, 250));
        }

        private void WayPoints6()
        {
            wayPoint.Enqueue(new Vector2(900, 600));

            //loop 3 times on 4 points
            wayPoint.Enqueue(new Vector2(550, 300));
            wayPoint.Enqueue(new Vector2(600, 250));
            wayPoint.Enqueue(new Vector2(700, 300));
            wayPoint.Enqueue(new Vector2(650, 350));
            wayPoint.Enqueue(new Vector2(550, 300));
            wayPoint.Enqueue(new Vector2(600, 250));
            wayPoint.Enqueue(new Vector2(700, 300));
            wayPoint.Enqueue(new Vector2(650, 350));
            wayPoint.Enqueue(new Vector2(550, 300));
            wayPoint.Enqueue(new Vector2(600, 250));
            wayPoint.Enqueue(new Vector2(700, 300));
            wayPoint.Enqueue(new Vector2(650, 350));

            //loop 3 times
            wayPoint.Enqueue(new Vector2(250, 350));
            wayPoint.Enqueue(new Vector2(200, 300));
            wayPoint.Enqueue(new Vector2(250, 250));
            wayPoint.Enqueue(new Vector2(350, 300));
            wayPoint.Enqueue(new Vector2(250, 350));
            wayPoint.Enqueue(new Vector2(200, 300));
            wayPoint.Enqueue(new Vector2(250, 250));
            wayPoint.Enqueue(new Vector2(350, 300));
            wayPoint.Enqueue(new Vector2(250, 350));
            wayPoint.Enqueue(new Vector2(200, 300));
            wayPoint.Enqueue(new Vector2(250, 250));
            wayPoint.Enqueue(new Vector2(350, 300));

            //loop 3 times
            wayPoint.Enqueue(new Vector2(450, 50));
            wayPoint.Enqueue(new Vector2(500, 100));
            wayPoint.Enqueue(new Vector2(450, 150));
            wayPoint.Enqueue(new Vector2(400, 100));
            wayPoint.Enqueue(new Vector2(450, 50));
            wayPoint.Enqueue(new Vector2(500, 100));
            wayPoint.Enqueue(new Vector2(450, 150));
            wayPoint.Enqueue(new Vector2(400, 100));
            wayPoint.Enqueue(new Vector2(450, 50));
            wayPoint.Enqueue(new Vector2(500, 100));
            wayPoint.Enqueue(new Vector2(450, 150));
            wayPoint.Enqueue(new Vector2(400, 100));

            wayPoint.Enqueue(new Vector2(450, 150));
            wayPoint.Enqueue(new Vector2(450, position.Y - 500));
        }

        public void Dive(Vector2 targetPosition, Vector2 originalPosition)
        {
            /* This function lets the enemy dive toward the player at their current position. If the player moves, they should
             * still follow the current path instead of following the player at every move. */

            float moveModX = 0.0f;      //be careful what number you use, or else the enemy will jitter and not move.
            float moveModY = 0.0f;
           


            /*move to point until destination is reached */

            if (position != targetPosition - new Vector2(50, 50)  && !diveFinished)
            {
                if (position.X < targetPosition.X - 50)
                    moveModX = 5.0f;
                if (position.Y < targetPosition.Y - 50)
                    moveModY = 5.0f;
                if (position.X > targetPosition.X - 50)
                    moveModX = -5.0f;
                if (position.Y > targetPosition.Y - 50)
                    moveModY = -5.0f;
            }
            else
            {
                diveFinished = true;
            }

            //move back to original position
            if (diveFinished)
            {
                if (position != originalPosition)
                {
                    if (position.X < originalPosition.X)
                        moveModX = 5.0f;
                    if (position.Y < originalPosition.Y)
                        moveModY = 5.0f;
                    if (position.X > originalPosition.X)
                        moveModX = -5.0f;
                    if (position.Y > originalPosition.Y)
                        moveModY = -5.0f;
                }
                else   //enemy's back at original position, reset dive timer
                    diveTimer = 300.0f;
            }
            
               
 
            //update position
            position.X += moveModX;
            position.Y += moveModY;

        }

        private void Capture(Vector2 target, Vector2 originalPosition)
        {
            /* This function allows an enemy to capture the player.  Only one random enemy can do this, and once one is captured,
             there can be no more captures until the player recovers the ship. */

            float moveModX = 0.0f;
            float moveModY = 0.0f;

            if (position != target && !captureFinished)
            {
                if (position.X < target.X)
                    moveModX = 5.0f;
                if (position.Y < target.Y)
                    moveModY = 5.0f;
                if (position.X > target.X)
                    moveModX = -5.0f;
                if (position.Y > target.Y)
                    moveModY = -5.0f;
            }
            else
            {
                captureFinished = true;
            }

             //move back to original position
            if (captureFinished)
            {
                if (position != originalPosition)
                {
                    if (position.X < originalPosition.X)
                        moveModX = 5.0f;
                    if (position.Y < originalPosition.Y)
                        moveModY = 5.0f;
                    if (position.X > originalPosition.X)
                        moveModX = -5.0f;
                    if (position.Y > originalPosition.Y)
                        moveModY = -5.0f;
                }
                else   //enemy's back at original position, reset capture timer
                    captureTimer = 300.0f;
            }

            position.X += moveModX;
            position.Y += moveModY;
        }

        private void MoveEnemyOnWaypoint()
        {
            
            float moveModX = 0.0f;      //be careful what number you use, or else the enemy will jitter and not move.
            float moveModY = 0.0f;

            
            /*move to point until destination is reached */
            if (wayPoint.Count > 0)
            {
                if (position != wayPoint.Peek())
                {
                    if (position.X < wayPoint.Peek().X)
                        moveModX = 10.0f;
                    if (position.Y < wayPoint.Peek().Y)
                        moveModY = 10.0f;
                    if (position.X > wayPoint.Peek().X)
                        moveModX = -10.0f;
                    if (position.Y > wayPoint.Peek().Y)
                        moveModY = -10.0f;
                    
                }
                else  //remove waypoint and move to next one
                {
                    wayPoint.Dequeue(); 
                }
            }


            //update position
            position.X += moveModX;
            position.Y += moveModY;

        }

        public void LineUp(float offset)
        {
            
            /* This function lines up the enemies in a row once they've finished their pathfinding */
            if (WaypointComplete())
            {
                //line up the enemy and create space between them
                //position.X = MathHelper.Lerp(position.X, position.X + offset, offset);
                
                position.X += offset;
         
            }
        }

        public void SetCoordinates(Vector2 pos)
        {
            originalPosition = pos;
        }

        public Vector2 GetOriginalCoordinates()
        {
            return originalPosition;
        }

        public bool OriginalPositionMarked()
        {
            return originalPositionMarked;
        }

        public void SetOriginalPositionStatus(bool pos)
        {
            originalPositionMarked = pos;
        }

        public bool TimeToDive()
        {
            return (diveTimer <= 0);
        }

        public bool TimeToCapture()
        {
            return (captureTimer <= 0);
        }

        public void SetDiveTimer(float time)
        {
            diveTimer = time;
        }

        public bool WaypointComplete()
        {
            return (wayPoint.Count == 0);
        }

        public void SetPositionStatus()
        {
            isPositioned = true;
        }

        public bool IsPositioned()
        {
            return isPositioned;
        }

        public void SetMovePatternX(float distance)
        {
            if (blnRight)
            {
                position.X += distance;
            }
            else
            {
                position.X -= distance;
            }
        }

       


        public void SetMovePatternY(float distance)
        {

            position.Y += distance;
        }
        /*
         *  Various Collision Test Routines
         * 
         */

        // --------------- INSERT VARIOUS COLLISION CODE HERE --------------
        // Collision: Enemy v.s. Fireball
        public bool CollisionTest(Fireball fireball)
        {
            bool testResult = false;

            if ((fireball.Position - position).Length() < this.radius + fireball.Radius && fireball.ShotByPlayer)
            {
                //we have collision
                testResult = true;
            }

            return testResult;
        }

        // --------------- INSERT VARIOUS COLLISION CODE HERE --------------

        /*
         *  GameScreen & XNA Connector Code (Update & Draw)
         * 
         */

        public void Draw(SpriteBatch batch)
        {
            batch.Draw(picture, position, null, Color.White, 0.0f, new Vector2(
            40.0f, 20.0f), 1.0f, SpriteEffects.None, 0.0f);
        }
        
        public void Update(GameTime gameTime)
        {

            //update timer
            diveTimer--;
            captureTimer--;

            float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
            //position.X += deltaX * elapsed;
            //position.Y += deltaY * elapsed;
          

            if (Position.X < xStart - xLength || Position.X > xStart + xLength)
                deltaX *= -1.0f;

            //position.Y += speed * elapsed;

            //enemy moves
            MoveEnemyOnWaypoint();

            //check if it's time to dive at the enemy
            //if (IsPositioned() && TimeToDive())
            //{
            //    //reset timer
            //    diveTimer = 300.0f;
            //}
           

            // enemy fires on a predictable period
            totalTime += elapsed;
            if (totalTime > fireSpeed)
            {
                totalTime = 0.0f;
                firing = true;
            }
            else // one shot, please
            {
                firing = false;
            }
        }

    }
}