﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SpaceShooter
{
    class Fireball
    {
        private Vector2     position;
        private Texture2D   fireballImage;
        private float       speed;
        private bool        shotByPlayer;
       

        public Fireball(Texture2D firePicture, Vector2 startPosition, float updateSpeed, bool bPlayerShot)
        {
            fireballImage = firePicture;
            position = startPosition;
            
            speed = updateSpeed;

            if (!bPlayerShot)       // invert the axis for enemy fire
                speed *= -1.0f;

            shotByPlayer = bPlayerShot;
        }

        public Vector2  Position        { get { return position; } }
        public float    Radius          { get { return 15.0f; } }
        public bool     ShotByPlayer    { get { return shotByPlayer; } }

        /*
         *  GameScreen & XNA Connector Code (Update & Draw)
         * 
         */

        public void Draw(SpriteBatch batch)
        {
            batch.Draw(fireballImage, position, null, Color.White, 0.0f, 
                new Vector2(10.0f, 10.0f), 1.0f, SpriteEffects.None, 1.0f);
        }

        public void Update(GameTime gameTime)
        {
            position.Y -= speed *
                (float)gameTime.ElapsedGameTime.TotalSeconds;
        }
    }
}
