﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SpaceShooter
{
    class Player
    {
        private Vector2 position;
        private Vector2 startPosition;

        public Vector2  Position     { get { return position; }   set { position = value; } }

        // total number of lives
        private uint lives = 5;
        public int Lives             { get { return (int)lives; } set { lives = (uint)value; } }
        
        private Animation playerAnimation;

        private int windowWidth;
        private int windowHeight;

        private float velocityY = 0.0f;

        private uint halfPlayerWidth;
        private uint halfPlayerHeight;

        // updated varaibles

        private float radius = 20.0f;
        private float blinkTime = 0.0f;
        private float blinkTimeTotal = 0.0f;

        private bool blinkOn = false;
        private bool recoveringActive = false;

        const float recoverLength = 3.0f;        

        public Player(GraphicsDevice device, Vector2 position, Vector2 origin)
        {
            // this position that is passed in is now 
            this.position       = position;
            this.startPosition  = position;
            this.lives = 3;

            // set the texture 2d
            playerAnimation = new Animation(position);
            playerAnimation.SpriteOrigin = origin;
            playerAnimation.Stop();

            //player halfwidth halfheight
            halfPlayerWidth = (uint)origin.X;
            halfPlayerHeight = (uint)origin.Y;

            // set window dimensions
            windowHeight = device.Viewport.Height;
            windowWidth = device.Viewport.Width;            
        }

        /*
         *  One member for managing the various animation cells of the player
         * 
         */

        public void AddCell(Texture2D cellPicture) { playerAnimation.AddCell(cellPicture, 0); }


        /*
         *  Action Members for utilizing player objects
         * 
         */

        public void playerAccelerate() { velocityY -= 20.0f; }
        public void playerReverse() { velocityY += 20.0f; }

        public void turnRight() { playerAnimation.GotoFrame(2); position.X += 3.0f; }
        public void turnLeft() { playerAnimation.GotoFrame(1); position.X -= 3.0f; }

        public void goStraight() { playerAnimation.GotoFrame(0); }

        private void hitByEnemy()
        {
            lives--;
            recoveringActive = true;
            blinkTimeTotal = 0.0f;
        }


        /*
         *  Various Collision Test Routines
         * 
         */


        // --------------- INSERT VARIOUS COLLISION CODE HERE --------------
        // Collision: Player v.s. Enemy
        public bool CollisionTest(Enemy enemy)
        {
            bool testResult = false;

            if ((enemy.Position - position).Length() < this.radius + enemy.Radius && !recoveringActive)
            {
                //we have collision
                hitByEnemy();
                testResult = true;
            }

            return testResult;
        }

        // Collision: Player v.s. Fireball
        public bool CollisionTest(Fireball fireball)
        {
            bool testResult = false;

            if ((fireball.Position - position).Length() < this.radius + fireball.Radius && !recoveringActive && !fireball.ShotByPlayer)
            {
                //we have collision
                hitByEnemy();
                testResult = true;
            }

            return testResult;
        }
        // --------------- INSERT VARIOUS COLLISION CODE HERE --------------

        /*
         *  GameScreen & XNA Connector Code (Update & Draw)
         * 
         */

        public void Draw(SpriteBatch batch)
        {
            playerAnimation.SetPosition(position);

            if (!recoveringActive || (recoveringActive && !blinkOn))
                playerAnimation.Draw(batch);
        }

        public void Update(GameTime gameTime)
        {
 
            if (position.X + halfPlayerWidth > windowWidth)
            {
               position.X = windowWidth - halfPlayerWidth;

            }
            else if (position.X - halfPlayerWidth < 0)
            {
                position.X = 0 + halfPlayerWidth;
            }

            if (position.Y - halfPlayerHeight < 0)
            {
                position.Y = 0 + halfPlayerHeight;
             
            }
            else if (position.Y + halfPlayerHeight > windowHeight)
            {
                position.Y = windowHeight - halfPlayerHeight;
            }

            if (recoveringActive)
            {
                const float blinkTimeSlice = 1.0f / 15.0f;
                float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
                blinkTime += elapsed;
                blinkTimeTotal += elapsed;
                if (blinkTimeTotal > recoverLength)
                    recoveringActive = false;

                else
                {
                    if (blinkTime > blinkTimeSlice)
                    {
                        blinkOn = !blinkOn;
                        blinkTime = 0.0f;
                    }
                }
            }

            position.Y += velocityY * (float)gameTime.ElapsedGameTime.TotalSeconds;
            velocityY *= 0.95f;
        }
    }
}
