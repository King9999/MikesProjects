﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace SpaceShooter.Screen
{
    class ScreenBase
    {
        protected Game theGame;

        public ScreenBase(Game game)
        {
            theGame = game;
        }

        // general operation methods
        public virtual void Init() { return; }
        public virtual void Destroy() { return; }
        public virtual void Update(GameTime gameTime) { return; }
        public virtual void Draw(GameTime gameTime) { return; }

        // is our screen still usable?
        public virtual bool isActive() { return false; }
    }
}
