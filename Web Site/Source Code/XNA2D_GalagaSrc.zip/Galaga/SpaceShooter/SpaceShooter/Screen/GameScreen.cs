﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SpaceShooter.Screen
{
    class GameScreen : ScreenBase
    {
        //load the background texture object
        private ParallaxScrolling backGroundTexture;
        private GraphicsDeviceManager graphics;
        private bool isGameActive = true;
        private SpriteBatch spriteBatch;


        //input bools
        private bool isPaused = false;      //checks when game is paused
        private bool pauseButtonPressed = false;    //prevents rapid pause/unpause
        private bool fireButtonPressed = false;     //prevent rapid fire
        private bool levelStarted = false;           //prevents pausing upon level start


        //audio variables
        private SoundEffect playerShot;
        private SoundEffect enemyDead; 
        private Song startMusic;            //Galaga theme
        private Song levelStart;
        private bool musicPlayed = false;   //lets the theme play once and only once per game

        //graphics variables
        private Animation deathAnimation;      //used when either an enemy or player dies

        //misc variables
        private int spawnTimer;         //used to control when enemies appear on screen
        static private int diveCount = 0;      //controls how many enemies dive
        private const int MAX_DIVE = 3;
        private Vector2 originalEnemyPosition;  //used to keep a copy of enemy's starting position before diving
        private bool positionSet = false;
        private const int WAYPOINT_ONE = 1;     //determines which waypoints the enemies should follow.  They should not clash
        private const int WAYPOINT_TWO = 2;
        private const int WAYPOINT_THREE = 3;
        private const int WAYPOINT_FOUR = 4;
        private const int WAYPOINT_FIVE = 5;
        private const int WAYPOINT_SIX = 6;

        Random num = new Random();  //used for choosing divers

        private int phaseCounter = 0;   //used to control which set of enemies appear on screen.  Should be 5 phases (0 to 4)


        public GameScreen(Game game, GraphicsDeviceManager gdm)
            : base(game)
        {
            graphics = gdm;
            spriteBatch = new SpriteBatch(theGame.GraphicsDevice);
        }

        /*
         *  HUD Management Code
         * 
         */

        private float points = 0.0f;                    // points accumulated
        private float hiScorePoints = 0.0f;             //tracks high score as long as game is running
        private float stateTimer = 0.0f;                // timer accumulator
        private const float screenPausePeriod = 1.5f;   // how long this screen should wait

        private SpriteFont hudFont;
        private SpriteFont statusFont;

        private Vector2 textLeft;
        

        private void DrawHud()
        {
            //string output = "Lives: " + player.Lives.ToString() + " Level: " + levelNumber.ToString();
            //spriteBatch.DrawString(hudFont, output, textLeft, Color.White);

            string pointString = points.ToString();
            string hiScoreString = hiScorePoints.ToString();
            string scoreText;
            string hiScoreText;
            Vector2 scoreTextPos = new Vector2(30, -5);
            Vector2 hiScoreTextPos = new Vector2(theGame.GraphicsDevice.Viewport.Width / 3.5f, -5);
            Vector2 hiScorePos;
            for (int i = pointString.Length; i < 8; i++)
            {
                pointString = "0" + pointString;
                
            }

            for (int i= hiScoreString.Length; i < 8; i++)
            {
                hiScoreString = "0" + hiScoreString;
            }

            // start with the top left screen value
            Vector2 textRight = textLeft;
            hiScorePos = textLeft;
            hiScorePos.X = theGame.GraphicsDevice.Viewport.Width / 3.5f;
           



            scoreText = "1UP";
            hiScoreText = "HIGH SCORE";


            Vector2 stringDimensions = hudFont.MeasureString(pointString);
            textRight.X = 10;

            spriteBatch.DrawString(hudFont, scoreText, scoreTextPos, Color.Red);
            spriteBatch.DrawString(hudFont, hiScoreText, hiScoreTextPos, Color.Red);
            spriteBatch.DrawString(hudFont, pointString, textRight, Color.White);
            spriteBatch.DrawString(hudFont, hiScoreString, hiScorePos, Color.White);
        }

        private void DrawPause()
        {
             //text info for pausing
            float screenWidth = theGame.GraphicsDevice.Viewport.Width;
            float screenHeight = theGame.GraphicsDevice.Viewport.Height;
            string pauseText = "-P A U S E-";
            Vector2 pauseTextPos = new Vector2(screenWidth / 2.4f, screenHeight / 2);
            spriteBatch.DrawString(hudFont, pauseText, pauseTextPos, Color.White);
        }

        private void DrawNotification(string Message)
        {
            // start with the screen middle value
            Vector2 trueMiddle = new Vector2(
                    theGame.GraphicsDevice.Viewport.Width / 2,
                    theGame.GraphicsDevice.Viewport.Height / 2);

            // we're going to ask the string how wide it is
            Vector2 stringDimensions = statusFont.MeasureString(Message);

            // we're going to subtract from the center, half of the strings width & height
            trueMiddle -= stringDimensions / 2;

            spriteBatch.DrawString(statusFont, Message, trueMiddle, Color.White);
        }

        /*
        *  Player Management Code
        * 
        */

        private Texture2D playerTexture;
        private Player player;
        

        private void Reload(GameTime gameTime)
        {
            if (player.Lives == 0)
            {
                isGameActive = false;
                player.Position = new Vector2(400.0f, 550.0f);
            }
        }

        /*
         *  Enemy Management Code
         * 
         */

        enum EnemyType
        {
            Green,
            Blue
        }

        enum EnemySet   //used to determine which sets of enemies are created in the enemyGenerator function
        {
            One = 1,
            Two,
            Three,
            Four,
            Five,
            Six
        }

        private Dictionary<EnemyType, Texture2D> enemyTemplate = new Dictionary<EnemyType, Texture2D>();

        /*
         *  GameScreen state tracking code
         * 
         */

        enum GameScreenState
        {
            Start = 1,
            Running,
            Stats
        }

        private GameScreenState gameScreenState = GameScreenState.Start;
        private int levelNumber = 0;

        private void changeState(GameScreenState state)
        {
            switch (state)
            {
                case GameScreenState.Start:
                    levelNumber++;

                    //reset level if players manages to complete all 3
                    if (levelNumber > 3)
                        levelNumber = 1;

                    MediaPlayer.Play(levelStart);
                    phaseCounter = 0;
                    spawnTimer = 0;
                    onLevelStart();
                    break;

                case GameScreenState.Running:
                    break;

                case GameScreenState.Stats:
                    if (player.Lives == 0)
                        onResetGame();

                    // set the player at the start position
                    player.Position = new Vector2(400.0f, 550.0f);
                    break;
            }

            gameScreenState = state;

            // we'll reset the state timer each time
            stateTimer = 0.0f;
        }


        // is the level complete?
        private bool levelComplete()
        {
            return (enemyList.Count == 0 && phaseCounter > 4) || player.Lives == 0;
        }

        private void onLevelStart()
        {
            fireballList.Clear();
            enemyList.Clear();
            
        }

       

        private void onResetGame()
        {
            // set the player at the start position and reset various counters
            player.Position = new Vector2(400.0f, 550.0f);
            player.Lives = 3;
            levelNumber = 0;
            points = 0.0f;
            phaseCounter = 0;
            musicPlayed = false;
                       
        }


        /*
         *  Enemy Management Code
         * 
         */

        private List<Enemy> enemyList = new List<Enemy>();

        
        private void enemyGenerator(EnemySet set)
        {
            /* When enemies are generated, they will come in from the sides from the screen and perform looping and other movement patterns before lining up. 
              Enemies should be generated off screen and then moved onto the visible screen*/

            //an array of starting positions is used for the different enemy patterns. In each position,
            //the enemy is offscreen and comes in using a given waypoint.
            Vector2[] startPosition = { new Vector2(-40, 400), new Vector2(100, -40), new Vector2(900, 500), new Vector2(700, -40), 
                                          new Vector2(-40, 100), new Vector2(900, 600) };



            Random rnd = new Random();

            //get width of the screen
            float screenWidth = theGame.GraphicsDevice.Viewport.Width;
            float stepSpeed = (float)(rnd.NextDouble() + 0.3d * (3.5d + (rnd.NextDouble() * 23.0d)));

            for (int i = 0; i < 8; i++)
            {
                
                //random fire delay
                float fireDelay = (float)(rnd.NextDouble() * 3.0d);

                //randomly choose next enemy to display
                EnemyType enemyType = (rnd.NextDouble() > 0.5d) ? EnemyType.Blue : EnemyType.Green;

                Enemy e;
                float spriteWidth = enemyTemplate[enemyType].Bounds.Width;
                switch (set)
                {

                    case EnemySet.One:
                        {
                            //I add (i* +/-50) to enemy position so that they follow each other in a line
                            e = new Enemy(enemyTemplate[enemyType], startPosition[0] + new Vector2(i * -50, 0), stepSpeed, fireDelay, WAYPOINT_ONE);
                             enemyList.Add(e);
                             break;
                        }


                    case EnemySet.Two:
                        {
                            e = new Enemy(enemyTemplate[enemyType], startPosition[1] + new Vector2(0, i * -50), stepSpeed, fireDelay, WAYPOINT_TWO);
                            enemyList.Add(e);
                            break;
                        }
                    case EnemySet.Three:
                        {
                            e = new Enemy(enemyTemplate[enemyType], startPosition[2] + new Vector2(i * 50, 0), stepSpeed, fireDelay, WAYPOINT_THREE);
                            enemyList.Add(e);
                            break;
                        }
                    case EnemySet.Four:
                        {
                            e = new Enemy(enemyTemplate[enemyType], startPosition[3] + new Vector2(0, i * -50), stepSpeed, fireDelay, WAYPOINT_FOUR);
                            enemyList.Add(e);
                            break;
                        }
                    case EnemySet.Five:
                        {
                            e = new Enemy(enemyTemplate[enemyType], startPosition[4] + new Vector2(i * -50, 0), stepSpeed, fireDelay, WAYPOINT_FIVE);
                            enemyList.Add(e);
                            break;
                        }
                    case EnemySet.Six:
                        {
                            e = new Enemy(enemyTemplate[enemyType], startPosition[5] + new Vector2(0, i * 50), stepSpeed, fireDelay, WAYPOINT_SIX);
                            enemyList.Add(e);
                            break;
                        }
                }              
                
            }
        }



        /*********This function controls the enemy spawns and at which phase. Once the player completes 5 phases,
        * the level ends. *********/
        private void StartPhase(int phase)
        {
            switch (phase)
            {
                case 0:
                    {
                        if (levelNumber == 1)
                        {
                            enemyGenerator(EnemySet.One);
                            enemyGenerator(EnemySet.Two);
                        }
                        else if (levelNumber == 2)
                        {
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Four);
                        }
                        else
                        {
                            enemyGenerator(EnemySet.Six);
                            enemyGenerator(EnemySet.Four);
                        }
                        break;
                    }
                case 1:
                    {
                        if (levelNumber == 1)
                        {
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Four);
                        }
                        else if (levelNumber == 2)
                        {
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Three);
                        }
                        else
                        {
                            enemyGenerator(EnemySet.One);
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Five);
                        }
                        break;
                    }
                case 2:
                    {
                        if (levelNumber == 1)
                        {
                            enemyGenerator(EnemySet.Three);
                        }
                        else if (levelNumber == 2)
                        {
                            enemyGenerator(EnemySet.Five);
                            enemyGenerator(EnemySet.Four);
                            enemyGenerator(EnemySet.Three);
                        }
                        else
                        {
                            enemyGenerator(EnemySet.Six);
                            enemyGenerator(EnemySet.Five);
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Three);
                        }
                        break;
                    }
                case 3:
                    {
                        if (levelNumber == 1)
                        {
                            enemyGenerator(EnemySet.One);
                        }
                        else if (levelNumber == 2)
                        {
                            enemyGenerator(EnemySet.One);
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Five);
                        }
                        else
                        {
                            enemyGenerator(EnemySet.One);
                            enemyGenerator(EnemySet.Six);
                            enemyGenerator(EnemySet.Four);
                        }
                        break;
                    }
                case 4:
                    {
                        if (levelNumber == 1)
                        {
                            enemyGenerator(EnemySet.Two);
                        }
                        else if (levelNumber == 2)
                        {
                            enemyGenerator(EnemySet.Five);
                            enemyGenerator(EnemySet.Four);
                        }
                        else
                        {
                            enemyGenerator(EnemySet.One);
                            enemyGenerator(EnemySet.Two);
                            enemyGenerator(EnemySet.Three);
                            enemyGenerator(EnemySet.Four);
                            enemyGenerator(EnemySet.Five);
                            enemyGenerator(EnemySet.Six);
                        }
                        break;
                    }
            }
        }

        /*
         *  Fireball management system
         * 
         */

        private const float fireballSpeed = 600.0f;

        private List<Fireball> fireballList = new List<Fireball>();


        public void createPlayerFireball(Vector2 startPosition)
        {
            fireballList.Add(new Fireball(theGame.Content.Load<Texture2D>(@"Images/Player/playerFireball"), startPosition, fireballSpeed, true));
        }

        public void createEnemyFireball(Vector2 startPosition)
        {
            fireballList.Add(new Fireball(theGame.Content.Load<Texture2D>(@"Images/Enemy/enemyFireball"), startPosition, fireballSpeed, false));
        }


        /*
         *  Original GameScreen : ScreenBase Code
         * 
         */

        // general operation methods
        public override void Init()
        {
            // ***** Our Background Scrolling Engine

            backGroundTexture = new ParallaxScrolling(graphics);

            Texture2D spaceBackgroundTexture = theGame.Content.Load<Texture2D>(@"Images/Backgrounds/spaceBackground");
            backGroundTexture.AddLayer(spaceBackgroundTexture, 0.0f, 200.0f);
            backGroundTexture.SetMoveUpDown();
            backGroundTexture.StartMoving();

            

            // ***** Our Player Object Code

            // early load this texture, so we can use some of its properties
            playerTexture = theGame.Content.Load<Texture2D>(@"Images/Player/playerSprite");


            // Create our player, pass position & graphics device
            player = new Player(
                            graphics.GraphicsDevice, 
                            new Vector2(400.0f, 550.0f),
                            // origin @ center of object
                            new Vector2(playerTexture.Width/2, playerTexture.Height/2)
                         );

            // add various player animation cells
            player.AddCell(playerTexture);


            /*******************Load up sounds ******************/
            playerShot = theGame.Content.Load<SoundEffect>(@"Sound/Shoot");
            startMusic = theGame.Content.Load<Song>(@"Sound/GalagaTheme");
            enemyDead = theGame.Content.Load<SoundEffect>(@"Sound/EnemyDie");
            levelStart = theGame.Content.Load<Song>(@"Sound/LevelStart");



            // ***** Our Enemy Image Loading

            enemyTemplate[EnemyType.Blue]  = theGame.Content.Load<Texture2D>(@"Images/Enemy/blueEnemy");
            enemyTemplate[EnemyType.Green] = theGame.Content.Load<Texture2D>(@"Images/Enemy/greenEnemy");
               

            // ***** Our HUD Related Startup

            // Load the fonts used by the various hud screens
            hudFont     = theGame.Content.Load<SpriteFont>(@"Fonts/HUD");
            statusFont  = theGame.Content.Load<SpriteFont>(@"Fonts/Status");

            // Calculate offsets for our onscreen text

            textLeft = new Vector2(
                graphics.GraphicsDevice.Viewport.Width / 30,
                graphics.GraphicsDevice.Viewport.Height / 30);

            // must engage changeState here (so other logic gets called)
            changeState(GameScreenState.Start);
        }

        public override void Destroy()
        {
            return;
        }

        private void UpdateInput(GameTime gameTime)
        {
            KeyboardState keyState = Keyboard.GetState();
            GamePadState gamePadState = GamePad.GetState(PlayerIndex.One);

            //pause key/pad input
            if ((keyState.IsKeyDown(Keys.X) || gamePadState.Buttons.Start == ButtonState.Pressed) && !pauseButtonPressed && levelStarted)
            {
                isPaused = !isPaused;
                pauseButtonPressed = true;
            }

            //we need the following to prevent rapid pausing/unpausing. This can cause an infinite loop once the state changes before the game can
            //be unpaused!
            if (keyState.IsKeyUp(Keys.X) && gamePadState.Buttons.Start == ButtonState.Released)
            {
                levelStarted = true;    //have this here so that game doesn't pause immediately upon level start
                pauseButtonPressed = false;
            }

            if (!isPaused)  //we want no control if game is paused
            {
                //if (keyState.IsKeyDown(Keys.Up) || gamePadState.DPad.Up == ButtonState.Pressed)
                //    player.playerAccelerate();

                if (keyState.IsKeyDown(Keys.Escape))
                    theGame.Exit();

                //if (keyState.IsKeyDown(Keys.Down) || gamePadState.DPad.Down == ButtonState.Pressed)
                //    player.playerReverse();

                if (keyState.IsKeyDown(Keys.Left) || gamePadState.DPad.Left == ButtonState.Pressed)
                    player.turnLeft();
                else
                    if (keyState.IsKeyDown(Keys.Right) || gamePadState.DPad.Right == ButtonState.Pressed)
                        player.turnRight();
                    else
                        player.goStraight();

                if ((keyState.IsKeyDown(Keys.RightControl) || gamePadState.Buttons.A == ButtonState.Pressed) && !fireButtonPressed)
                {
                    playerShot.Play();      //play sound effect
                    createPlayerFireball(player.Position + new Vector2(0, -25));    //fireball is generated in front of the ship
                    fireButtonPressed = true;
                }

                //we need the following to prevent rapid fire. 
                if (keyState.IsKeyUp(Keys.RightControl) && gamePadState.Buttons.A == ButtonState.Released)
                     fireButtonPressed = false;

            }


        }



        private bool isStartKey()
        {
            return GamePad.GetState(PlayerIndex.One).Buttons.Start == ButtonState.Pressed;
        }

        public override void Update(GameTime gameTime)
        {
            float screenWidth = theGame.GraphicsDevice.Viewport.Width;
            float screenHeight = theGame.GraphicsDevice.Viewport.Height;
            const float LEFT_BOUNDARY = 150.0f; //enemies cannot go past these boundaries
            const float RIGHT_BOUNDARY = 600.0f;

            if (!isPaused)  //stop background if paused
                backGroundTexture.Update(gameTime);

            switch (gameScreenState)
            {
                case GameScreenState.Stats:
                    levelStarted = false;   //need this here so that game doesn't pause upon level start
                    
                    if (isStartKey() && stateTimer > screenPausePeriod)
                    {
                       
                        changeState(GameScreenState.Start);
                    }
                    break;

                case GameScreenState.Start:
                    levelStarted = false;
                    if (!musicPlayed)
                    {
                        MediaPlayer.Play(startMusic);
                        musicPlayed = true;
                    }
                    if (isStartKey() && stateTimer > screenPausePeriod)
                    {
                        
                        changeState(GameScreenState.Running);
                    }
                    break;

                case GameScreenState.Running:
                    {
                        if (!isPaused)
                        {
                            //check for spawns
                            spawnTimer--;
                            if (spawnTimer < 0 || enemyList.Count == 0)
                            {
                                StartPhase(phaseCounter);
                                spawnTimer = 600;
                                phaseCounter++;
                            }
                            
                
                            float viewPortHeight = (float)theGame.GraphicsDevice.Viewport.Height;

                            UpdateInput(gameTime);
                            player.Update(gameTime);

                            // update all the fireballs
                            for (int j = 0; j < fireballList.Count; j++)
                            {
                                Fireball f = fireballList[j];

                                f.Update(gameTime);

                                // has the fireball gone offscreen?
                                if (f.Position.Y < 0.0f || f.Position.Y > viewPortHeight)
                                    fireballList.RemoveAt(j);

                            }


                            // update all the enemies
                            for (int i = 0; i < enemyList.Count; i++)
                            {
                                Enemy e = enemyList[i];

                                e.Update(gameTime);


                                //Put enemies into position and create space between them. This only happens once for each enemy.
                                if (e.WaypointComplete() && !e.IsPositioned())
                                {
                                    //e.LineUp(i * 80);
                                    e.SetPositionStatus();
                                }

                                // is this enemy awaiting to fire?
                                if (e.Firing && e.IsPositioned())
                                    createEnemyFireball(e.Position);

                                
                                //move enemy
                                if (e.IsPositioned())
                                {
                                    if (e.Position.X <= RIGHT_BOUNDARY && e.blnRight)
                                    {
                                        e.blnRight = true; 
                                        e.SetMovePatternX(2.0f);
                                    }
                                    else if (e.Position.X > LEFT_BOUNDARY && !e.blnRight) // moving left 
                                    {
                                        e.blnRight = false;
                                        e.SetMovePatternX(2.0f);
                                    }
                                    else 
                                    {
                                        //change direction of all enemies once one enemy is at edge of screen and move them down
                                        //e.SetMovePatternY(50.0f);
                                        foreach (Enemy f in enemyList)
                                            f.blnRight =  f.blnRight ? false : true; // slick coding to invert a bool 
                                    }
                                }

                                //any enemies that are off screen after lining up should die,
                                //or else level can't be completed.
                                if ((e.Position.Y < 0 || e.Position.Y > viewPortHeight) && e.IsPositioned())
                                    enemyList.RemoveAt(i);

                                //check if enemy dives at player
                                if (e.TimeToDive() && e.IsPositioned())
                                {
                                    
                                    
                                    //only a certain number of enemies should dive at a time
                                    int p = num.Next(100);
                                    if (p <= 30)
                                    {
                                        if (!e.OriginalPositionMarked() && diveCount != MAX_DIVE)
                                        {
                                            e.SetCoordinates(e.Position);
                                            e.SetOriginalPositionStatus(true);
                                            diveCount++;
                                            
                                        }


                                        //e.Dive(player.Position, originalEnemyPosition);
                                        //e.SetDiveTimer(300.0f);
                                    }

                                    if (e.OriginalPositionMarked())
                                    {
                                        e.Dive(player.Position, e.GetOriginalCoordinates());

                                        //if the enemy's back at its original spot, then reduce dive counter
                                        if (e.Position == e.GetOriginalCoordinates())
                                        {
                                            e.SetOriginalPositionStatus(false);
                                            diveCount--;
                                        }
                                    }
                                    
                                }
                            }

                            // --------------- INSERT VARIOUS COLLISION CODE HERE --------------
                            // Collision: Fireballs v.s. Player & Enemies
                            for (int j = 0; j < fireballList.Count; j++)
                            {
                                bool removeFireball = false;

                                for (int i = 0; i < enemyList.Count; i++)
                                {
                                    //did a fireball hit the enemy?
                                    if (enemyList[i].CollisionTest(fireballList[j]))
                                    {
                                        points += 100;
                                        if (points > hiScorePoints)
                                            hiScorePoints = points;

                                        //extra life given every 10,000 points
                                        if (points % 10000 == 0)
                                        {
                                            MediaPlayer.Play(levelStart);
                                            player.Lives++;
                                        }

                                        //check if he was a diver
                                        if (enemyList[i].OriginalPositionMarked())
                                        {
                                            diveCount--;
                                        }

                                        enemyDead.Play();
                                        enemyList.RemoveAt(i);
                                       
                                        removeFireball = true;
                                    }
                                }

                                //did the fireball hit the player?
                                if (player.CollisionTest(fireballList[j]) && !removeFireball)
                                    removeFireball = true;

                                if (removeFireball)
                                    fireballList.RemoveAt(j);
                            }


                            // Collision: Player v.s. Enemy Ship 
                            for (int i = 0; i < enemyList.Count; i++)
                            {
                                if (player.CollisionTest(enemyList[i]))
                                {
                                    enemyDead.Play();
                                    enemyList.RemoveAt(i);
                                }
                            }

                            // check if the level is complete in any way?
                            if (levelComplete() && stateTimer > screenPausePeriod)
                                changeState(GameScreenState.Stats);

                            
                        }
                        else   //game is paused, wait for input to unpause
                        {

                            UpdateInput(gameTime);
                        }
                           
                    }
                        
                    break;
            }

            if (!isPaused)  //freeze the timer if true
                stateTimer += gameTime.ElapsedGameTime.Milliseconds / 1000.0f;
        }
            
        

        public override void Draw(GameTime gameTime)
        {
            // start drawing
            spriteBatch.Begin();

                // draw the scrolling background
                backGroundTexture.Draw();

                switch (gameScreenState)
                {
                    case GameScreenState.Start:
                        {
                            DrawNotification("Press Start Key To Begin");
                            break;
                        }

                    case GameScreenState.Running:
                        // draw player
                        player.Draw(spriteBatch);

                        //draw lives
                        for (int i = 0; i < player.Lives-1; i++)
                        {
                            int playerWidth = (int)playerTexture.Width / 2;
                            int playerHeight = (int)playerTexture.Height / 2;
                            spriteBatch.Draw(playerTexture, new Rectangle(100 + i * 45, 570, playerWidth, playerHeight), Color.White);
                        }

                        // draw fireballs
                        foreach (Fireball f in fireballList)
                            f.Draw(spriteBatch);

                        // draw all the enemies
                        foreach (Enemy e in enemyList)
                            e.Draw(spriteBatch);

                        //draw pause text if paused
                        if (isPaused)
                            DrawPause();

                        break;

                    case GameScreenState.Stats:
                        if (levelNumber > 0)
                            DrawNotification("Get ready for the next level!");
                        else
                            DrawNotification("Game Over! (Press Start)");
                        break;
                }

                // draw the hud elements
                DrawHud();

            // end drawing
            spriteBatch.End();
        }

        // is our screen still usable?
        public override bool isActive()
        {
            return isGameActive;
        }

    }
}
