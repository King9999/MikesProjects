﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using SpaceShooter.Screen;

namespace SpaceShooter.Screen
{
    class WaitScreen : ScreenBase
    {
        // Textures for our splash screen
        Texture2D theScreen;
        String theAssetName;

        float waitCounter = 0.0f;
        float waitExpire = 0.0f;
        bool screenActive = true;
        SpriteBatch spriteBatch;

        public WaitScreen(Game game, String AssetName, float screenWaitTime)
            : base(game)
        {
            spriteBatch = new SpriteBatch(theGame.GraphicsDevice);
            theAssetName = AssetName;

            waitExpire = screenWaitTime;
            return;
        }

        public override void Init()
        {
            theScreen = theGame.Content.Load<Texture2D>(theAssetName);
        }

        public override void Destroy()
        {
            return;
        }

        public override void Update(GameTime gameTime)
        {
            waitCounter += gameTime.ElapsedGameTime.Milliseconds / 1000.0f;
            if (waitCounter > waitExpire)
            {
                screenActive = false;
            }
        }

        public override void Draw(GameTime gameTime)
        {
            if (screenActive)
            {
                spriteBatch.Begin();
                spriteBatch.Draw(theScreen, Vector2.Zero, Color.White);
                spriteBatch.End();
            }
        }

        public override bool isActive() { return screenActive; }
    }
}
