/* Card.cpp 
Author: Mike Murray (mike_murray56@hotmail.com) */

#include "Card.h"

//initialize the Card class
Card::Card(int ID, int val, string su)
{
	id = ID;
	value = val;
	suit = su;
}





